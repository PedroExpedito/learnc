#ifdef _MODULO_H_
#define _MODULO_H_

int fatorial(int n);
int quad(int n);

#endif

