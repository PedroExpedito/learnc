#include <iostream>
#include "modulo.h"


using namespace std;

int main(void){

  int i = fatorial(3);
  cout << "Fatorial" << i << endl;

}
