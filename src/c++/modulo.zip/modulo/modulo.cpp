/* Modulos Matematica*/

int fatorial(int n) {
  for(int i = n; i > 0; i--){
    n * i;
  }
  return n;
}

int quad (int n){
  return n * n;
}

